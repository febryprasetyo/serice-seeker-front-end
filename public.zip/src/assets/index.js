import Logo from './logo seeker.png';
import close from './close.svg';
import menu from './menu.svg';
import shield from './Shield.svg';
import star from './Star.svg';
import send from './Send.svg';

export { Logo, close, menu, shield, star, send };
