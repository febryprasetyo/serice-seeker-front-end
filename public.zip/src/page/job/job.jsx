import React from 'react';

const Job = () => {
  return <div>job</div>;
};

export default Job;
