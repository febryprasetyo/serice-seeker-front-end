import React from 'react';

const CardCategory = () => {
  return <div>CardCategory</div>;
};

export default CardCategory;
