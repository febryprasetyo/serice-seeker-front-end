import Logo from './logo seeker.png';
import close from './close.svg';
import menu from './menu.svg';
import shield from './Shield.svg';
import star from './star.svg';
import send from './send.svg';

export { Logo, close, menu, shield, star, send };
